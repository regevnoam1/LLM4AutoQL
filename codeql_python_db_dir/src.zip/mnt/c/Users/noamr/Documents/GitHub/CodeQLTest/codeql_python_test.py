
def calculate_sum(a, b):
    """Calculate the sum of two numbers."""
    return a + b

def main():
    result = calculate_sum(5, 3)
    print("The sum is:", result)

if __name__ == "__main__":
    main()